import { Namespace } from '../readers/types/content-type-reader';
import { caseType } from '../utils/casing';
import Interface from './Interface';
export default class ComponentInterface extends Interface {
    protected Category: string;
    protected Options: Record<string, any>;
    constructor(baseName: string, namespace: Namespace, attributes: any, relativeDirectoryPath: string, category: string, fileCase: caseType, prefix?: string, options?: Record<string, any>);
    updateStrapiName(): void;
    getFullName(): string;
    getInerfaceString(): string;
    getInterfaceFieldsString(): string;
}
