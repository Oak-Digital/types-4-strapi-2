import { caseType } from '../utils/casing';
import Attributes from '../attributes/Attributes';
import { File } from '../file/File';
import { AttributeWithNested } from './builtinInterfaces';
import { Namespace } from '../readers/types/content-type-reader';
export default class Interface extends File {
    protected NamePrefix: string;
    protected Attributes: Record<string, AttributeWithNested>;
    protected CollectionName: string | null;
    protected Namespace: Namespace;
    constructor(baseName: string, namespace: Namespace, attributes: Record<string, AttributeWithNested>, relativeDirectoryPath: string, collectionName?: string | null, fileCaseType?: caseType, prefix?: string);
    protected updateStrapiName(): void;
    getStrapiName(): string;
    getDependencies(): string[];
    getFullName(): string;
    hasPopulatableAttributes(): boolean;
    getAttributes(): Attributes;
    attributesToString(): string;
    getInerfaceString(): string;
    getInterfaceFieldsString(): string;
    toString(): string;
}
