import { z } from 'zod';
import { caseType } from '../utils/casing';
import BuiltinComponentInterface from './BuiltinComponentInterface';
import BuiltinInterface from './BuiltinInterface';
export declare const nestedAttribute: z.ZodObject<{
    type: z.ZodLiteral<"nested">;
    nullable: z.ZodOptional<z.ZodBoolean>;
    fields: z.ZodRecord<z.ZodString, z.ZodUnion<[z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"dynamiczone">;
        components: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "dynamiczone";
        components?: string[];
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "dynamiczone";
        components?: string[];
    }>, z.ZodUnion<[z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodEnum<["text", "string"]>;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "string" | "text";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "string" | "text";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"email">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "email";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "email";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"uid">;
        targetField: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "uid";
        targetField?: string;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "uid";
        targetField?: string;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"richtext">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "richtext";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "richtext";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"blocks">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "blocks";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "blocks";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"json">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "json";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "json";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"password">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "password";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "password";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"integer">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "integer";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "integer";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"float">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "float";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "float";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"biginteger">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "biginteger";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "biginteger";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"decimal">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "decimal";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "decimal";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"enumeration">;
        enum: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "enumeration";
        enum?: string[];
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "enumeration";
        enum?: string[];
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"date">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "date";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "date";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"datetime">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "datetime";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "datetime";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"time">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "time";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "time";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"media">;
        multiple: z.ZodOptional<z.ZodBoolean>;
        allowedTypes: z.ZodDefault<z.ZodOptional<z.ZodArray<z.ZodEnum<["images", "videos", "audios", "files"]>, "many">>>;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "media";
        multiple?: boolean;
        allowedTypes?: ("images" | "videos" | "audios" | "files")[];
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "media";
        multiple?: boolean;
        allowedTypes?: ("images" | "videos" | "audios" | "files")[];
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"boolean">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "boolean";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "boolean";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        target: z.ZodString;
    } & {
        relation: z.ZodLiteral<"oneToOne">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        target: z.ZodString;
    } & {
        relation: z.ZodLiteral<"oneToOne">;
        inversedBy: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
        inversedBy?: string;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
        inversedBy?: string;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        target: z.ZodString;
    } & {
        mappedBy: z.ZodString;
        relation: z.ZodLiteral<"oneToMany">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
        mappedBy?: string;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
        mappedBy?: string;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        target: z.ZodString;
    } & {
        relation: z.ZodLiteral<"manyToOne">;
        inversedBy: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToOne";
        target?: string;
        inversedBy?: string;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToOne";
        target?: string;
        inversedBy?: string;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        target: z.ZodString;
    } & {
        relation: z.ZodLiteral<"manyToMany">;
        inversedBy: z.ZodOptional<z.ZodString>;
        mappedBy: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToMany";
        target?: string;
        inversedBy?: string;
        mappedBy?: string;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToMany";
        target?: string;
        inversedBy?: string;
        mappedBy?: string;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        target: z.ZodString;
    } & {
        relation: z.ZodLiteral<"oneToMany">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        relation: z.ZodLiteral<"morphToMany">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToMany";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToMany";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        relation: z.ZodLiteral<"morphToOne">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToOne";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToOne";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"component">;
        repeatable: z.ZodOptional<z.ZodBoolean>;
        component: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "component";
        component?: string;
        repeatable?: boolean;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "component";
        component?: string;
        repeatable?: boolean;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
    }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
    }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
    }, z.ZodTypeAny, "passthrough">>]>]>>;
}, "strip", z.ZodTypeAny, {
    type?: "nested";
    nullable?: boolean;
    fields?: Record<string, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "string" | "text";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "email";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "uid";
        targetField?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "richtext";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "blocks";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "json";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "password";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "integer";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "float";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "biginteger";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "decimal";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "enumeration";
        enum?: string[];
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "date";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "datetime";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "time";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "media";
        multiple?: boolean;
        allowedTypes?: ("images" | "videos" | "audios" | "files")[];
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "boolean";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
        inversedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
        mappedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToOne";
        target?: string;
        inversedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToMany";
        target?: string;
        inversedBy?: string;
        mappedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToMany";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToOne";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "component";
        component?: string;
        repeatable?: boolean;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "dynamiczone";
        components?: string[];
    } | z.objectOutputType<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
    }, z.ZodTypeAny, "passthrough">>;
}, {
    type?: "nested";
    nullable?: boolean;
    fields?: Record<string, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "string" | "text";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "email";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "uid";
        targetField?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "richtext";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "blocks";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "json";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "password";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "integer";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "float";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "biginteger";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "decimal";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "enumeration";
        enum?: string[];
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "date";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "datetime";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "time";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "media";
        multiple?: boolean;
        allowedTypes?: ("images" | "videos" | "audios" | "files")[];
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "boolean";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
        inversedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
        mappedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToOne";
        target?: string;
        inversedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToMany";
        target?: string;
        inversedBy?: string;
        mappedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToMany";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToOne";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "component";
        component?: string;
        repeatable?: boolean;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "dynamiczone";
        components?: string[];
    } | z.objectInputType<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
    }, z.ZodTypeAny, "passthrough">>;
}>;
export declare const attributeWithNested: z.ZodUnion<[z.ZodUnion<[z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"dynamiczone">;
    components: z.ZodArray<z.ZodString, "many">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "dynamiczone";
    components?: string[];
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "dynamiczone";
    components?: string[];
}>, z.ZodUnion<[z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEnum<["text", "string"]>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "string" | "text";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "string" | "text";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"email">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "email";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "email";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"uid">;
    targetField: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "uid";
    targetField?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "uid";
    targetField?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"richtext">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "richtext";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "richtext";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"blocks">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "blocks";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "blocks";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"json">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "json";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "json";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"password">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "password";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "password";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"integer">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "integer";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "integer";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"float">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "float";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "float";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"biginteger">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "biginteger";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "biginteger";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"decimal">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "decimal";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "decimal";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"enumeration">;
    enum: z.ZodArray<z.ZodString, "many">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "enumeration";
    enum?: string[];
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "enumeration";
    enum?: string[];
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"date">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "date";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "date";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"datetime">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "datetime";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "datetime";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"time">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "time";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "time";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"media">;
    multiple: z.ZodOptional<z.ZodBoolean>;
    allowedTypes: z.ZodDefault<z.ZodOptional<z.ZodArray<z.ZodEnum<["images", "videos", "audios", "files"]>, "many">>>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "media";
    multiple?: boolean;
    allowedTypes?: ("images" | "videos" | "audios" | "files")[];
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "media";
    multiple?: boolean;
    allowedTypes?: ("images" | "videos" | "audios" | "files")[];
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"boolean">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "boolean";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "boolean";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToOne">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToOne">;
    inversedBy: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
    inversedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
    inversedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    mappedBy: z.ZodString;
    relation: z.ZodLiteral<"oneToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
    mappedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
    mappedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"manyToOne">;
    inversedBy: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToOne";
    target?: string;
    inversedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToOne";
    target?: string;
    inversedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"manyToMany">;
    inversedBy: z.ZodOptional<z.ZodString>;
    mappedBy: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToMany";
    target?: string;
    inversedBy?: string;
    mappedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToMany";
    target?: string;
    inversedBy?: string;
    mappedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    relation: z.ZodLiteral<"morphToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToMany";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToMany";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    relation: z.ZodLiteral<"morphToOne">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToOne";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToOne";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"component">;
    repeatable: z.ZodOptional<z.ZodBoolean>;
    component: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "component";
    component?: string;
    repeatable?: boolean;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "component";
    component?: string;
    repeatable?: boolean;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
}, "passthrough", z.ZodTypeAny, z.objectOutputType<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
}, z.ZodTypeAny, "passthrough">, z.objectInputType<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
}, z.ZodTypeAny, "passthrough">>]>]>, z.ZodObject<{
    type: z.ZodLiteral<"nested">;
    nullable: z.ZodOptional<z.ZodBoolean>;
    fields: z.ZodRecord<z.ZodString, z.ZodUnion<[z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"dynamiczone">;
        components: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "dynamiczone";
        components?: string[];
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "dynamiczone";
        components?: string[];
    }>, z.ZodUnion<[z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodEnum<["text", "string"]>;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "string" | "text";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "string" | "text";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"email">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "email";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "email";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"uid">;
        targetField: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "uid";
        targetField?: string;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "uid";
        targetField?: string;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"richtext">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "richtext";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "richtext";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"blocks">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "blocks";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "blocks";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"json">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "json";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "json";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"password">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "password";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "password";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"integer">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "integer";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "integer";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"float">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "float";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "float";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"biginteger">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "biginteger";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "biginteger";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"decimal">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "decimal";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "decimal";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"enumeration">;
        enum: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "enumeration";
        enum?: string[];
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "enumeration";
        enum?: string[];
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"date">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "date";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "date";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"datetime">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "datetime";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "datetime";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"time">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "time";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "time";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"media">;
        multiple: z.ZodOptional<z.ZodBoolean>;
        allowedTypes: z.ZodDefault<z.ZodOptional<z.ZodArray<z.ZodEnum<["images", "videos", "audios", "files"]>, "many">>>;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "media";
        multiple?: boolean;
        allowedTypes?: ("images" | "videos" | "audios" | "files")[];
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "media";
        multiple?: boolean;
        allowedTypes?: ("images" | "videos" | "audios" | "files")[];
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"boolean">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "boolean";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "boolean";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        target: z.ZodString;
    } & {
        relation: z.ZodLiteral<"oneToOne">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        target: z.ZodString;
    } & {
        relation: z.ZodLiteral<"oneToOne">;
        inversedBy: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
        inversedBy?: string;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
        inversedBy?: string;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        target: z.ZodString;
    } & {
        mappedBy: z.ZodString;
        relation: z.ZodLiteral<"oneToMany">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
        mappedBy?: string;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
        mappedBy?: string;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        target: z.ZodString;
    } & {
        relation: z.ZodLiteral<"manyToOne">;
        inversedBy: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToOne";
        target?: string;
        inversedBy?: string;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToOne";
        target?: string;
        inversedBy?: string;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        target: z.ZodString;
    } & {
        relation: z.ZodLiteral<"manyToMany">;
        inversedBy: z.ZodOptional<z.ZodString>;
        mappedBy: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToMany";
        target?: string;
        inversedBy?: string;
        mappedBy?: string;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToMany";
        target?: string;
        inversedBy?: string;
        mappedBy?: string;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        target: z.ZodString;
    } & {
        relation: z.ZodLiteral<"oneToMany">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        relation: z.ZodLiteral<"morphToMany">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToMany";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToMany";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"relation">;
        relation: z.ZodLiteral<"morphToOne">;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToOne";
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToOne";
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodLiteral<"component">;
        repeatable: z.ZodOptional<z.ZodBoolean>;
        component: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "component";
        component?: string;
        repeatable?: boolean;
    }, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "component";
        component?: string;
        repeatable?: boolean;
    }>, z.ZodObject<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
    }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
    }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
    }, z.ZodTypeAny, "passthrough">>]>]>>;
}, "strip", z.ZodTypeAny, {
    type?: "nested";
    nullable?: boolean;
    fields?: Record<string, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "string" | "text";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "email";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "uid";
        targetField?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "richtext";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "blocks";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "json";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "password";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "integer";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "float";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "biginteger";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "decimal";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "enumeration";
        enum?: string[];
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "date";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "datetime";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "time";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "media";
        multiple?: boolean;
        allowedTypes?: ("images" | "videos" | "audios" | "files")[];
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "boolean";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
        inversedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
        mappedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToOne";
        target?: string;
        inversedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToMany";
        target?: string;
        inversedBy?: string;
        mappedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToMany";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToOne";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "component";
        component?: string;
        repeatable?: boolean;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "dynamiczone";
        components?: string[];
    } | z.objectOutputType<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
    }, z.ZodTypeAny, "passthrough">>;
}, {
    type?: "nested";
    nullable?: boolean;
    fields?: Record<string, {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "string" | "text";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "email";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "uid";
        targetField?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "richtext";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "blocks";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "json";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "password";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "integer";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "float";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "biginteger";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "decimal";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "enumeration";
        enum?: string[];
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "date";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "datetime";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "time";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "media";
        multiple?: boolean;
        allowedTypes?: ("images" | "videos" | "audios" | "files")[];
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "boolean";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToOne";
        target?: string;
        inversedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
        mappedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToOne";
        target?: string;
        inversedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "manyToMany";
        target?: string;
        inversedBy?: string;
        mappedBy?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "oneToMany";
        target?: string;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToMany";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "relation";
        relation?: "morphToOne";
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "component";
        component?: string;
        repeatable?: boolean;
    } | {
        __t4s_required?: boolean;
        pluginOptions?: any;
        required?: boolean;
        type?: "dynamiczone";
        components?: string[];
    } | z.objectInputType<{
        pluginOptions: z.ZodOptional<z.ZodAny>;
        required: z.ZodOptional<z.ZodBoolean>;
        __t4s_required: z.ZodOptional<z.ZodBoolean>;
    } & {
        type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
    }, z.ZodTypeAny, "passthrough">>;
}>]>;
export type AttributeWithNested = z.infer<typeof attributeWithNested>;
export declare function createMediaInterface(caseTypeName: caseType, prefix: string): BuiltinInterface;
export declare function createMediaFormatInterface(caseTypeName: caseType, prefix: string): BuiltinComponentInterface;
