import { caseType } from '../utils/casing';
export type RelationNames = Record<string, {
    name: string;
    file: File;
}>;
export declare abstract class File {
    private Relations;
    protected RelationNames: RelationNames;
    private RelationNamesCounter;
    protected BaseName: string;
    protected StrapiName: string;
    private RelativeDirectoryPath;
    protected FileCase: caseType;
    constructor(baseName: string, relativeDirectoryPath: string, fileCaseType?: caseType);
    abstract getDependencies(): string[];
    abstract getStrapiName(): string;
    abstract getFullName(): string;
    abstract toString(): string;
    setRelations(relations: File[]): void;
    getRelativeRootPath(): any;
    getBaseName(): string;
    getRelativeRootPathFile(): string;
    getRelativeRootDir(): string;
    getFileBaseName(): string;
    protected getTsImports(): string;
}
