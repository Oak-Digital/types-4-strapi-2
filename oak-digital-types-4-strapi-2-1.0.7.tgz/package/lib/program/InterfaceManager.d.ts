import { caseType } from '../utils/casing/';
import { SupportedPluginNamesType } from '../plugins/types';
import { File } from '../file/File';
import { ContentTypeReader } from '../readers/types/content-type-reader';
import { InterfaceWriter } from '../writers/types/writer';
type InterfaceManagerOptions = {
    /**
     * @default 'I'
     * @type {string}
     * @description The prefix to use for all interfaces
     */
    prefix?: string;
    /**
     * @default true
     * @type {boolean}
     * @description Whether to use the category prefix for component interfaces
     */
    useCategoryPrefix?: boolean;
    /**
     * @default ''
     * @type {string}
     * @description The prefix to use for component interfaces
     */
    componentPrefix?: string;
    /**
     * @default false
     * @type {boolean}
     * @description Whether to use only the component prefix for component interfaces
     */
    componentPrefixOverridesPrefix?: boolean;
    /**
     * @default ''
     * @type {string}
     * @description The prefix to use for builtin interfaces
     */
    /**
     * @default false
     * @type {boolean}
     * @description Whether to use only the builtin prefix for builtin interfaces
     */
    /**
     * @default null
     * @type {string}
     * @description The path to the prettier config file
     */
    fileCaseType?: caseType;
    /**
     * @default 'kebab'
     * @type {caseType}
     * @description The case type to use for folder names
     */
    folderCaseType?: caseType;
    /**
     * @default []
     * @type {SupportedPluginNamesType[]}
     * @description The plugins to use
     */
    enabledPlugins?: SupportedPluginNamesType[];
};
export default class InterfaceManager {
    private Files;
    private Options;
    private PluginManager;
    private dependenciesInjected;
    private contentTypeReader;
    private interfaceWriter;
    constructor(reader: ContentTypeReader, writer: InterfaceWriter, { prefix, useCategoryPrefix, componentPrefix, componentPrefixOverridesPrefix, fileCaseType, folderCaseType, enabledPlugins, }?: Partial<InterfaceManagerOptions>);
    registerBuiltinPlugins(): void;
    registerPlugin(): void;
    validateOptions(): void;
    readSchemas(): Promise<{
        apiSchemas: Record<`api::${string}` | `plugin::${string}` | `admin::${string}` | `builtins::${string}`, {
            name: string;
            contentType: import("../readers/types/content-type").StrapiContentType;
        } & ({
            namespace: "api" | "plugin";
            collection: string;
        } | {
            namespace: "admin";
            collection?: null | undefined;
        })>;
        componentSchemas: Record<`${string}.${string}`, {
            options?: {};
            uid?: string;
            collectionName?: string;
            attributes?: Record<string, {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "string" | "text";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "email";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "uid";
                targetField?: string;
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "richtext";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "blocks";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "json";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "password";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "integer";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "float";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "biginteger";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "decimal";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "enumeration";
                enum?: string[];
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "date";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "datetime";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "time";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "media";
                multiple?: boolean;
                allowedTypes?: ("images" | "videos" | "audios" | "files")[];
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "boolean";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "relation";
                relation?: "oneToOne";
                target?: string;
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "relation";
                relation?: "oneToOne";
                target?: string;
                inversedBy?: string;
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "relation";
                relation?: "oneToMany";
                target?: string;
                mappedBy?: string;
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "relation";
                relation?: "manyToOne";
                target?: string;
                inversedBy?: string;
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "relation";
                relation?: "manyToMany";
                target?: string;
                inversedBy?: string;
                mappedBy?: string;
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "relation";
                relation?: "oneToMany";
                target?: string;
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "relation";
                relation?: "morphToMany";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "relation";
                relation?: "morphToOne";
            } | {
                __t4s_required?: boolean;
                pluginOptions?: any;
                required?: boolean;
                type?: "component";
                component?: string;
                repeatable?: boolean;
            } | import("zod").objectOutputType<{
                pluginOptions: import("zod").ZodOptional<import("zod").ZodAny>;
                required: import("zod").ZodOptional<import("zod").ZodBoolean>;
                __t4s_required: import("zod").ZodOptional<import("zod").ZodBoolean>;
            } & {
                type: import("zod").ZodEffects<import("zod").ZodType<"any", import("zod").ZodTypeDef, "any">, "any", "any">;
            }, import("zod").ZodTypeAny, "passthrough">>;
        }>;
    }>;
    addType(name: string, file: File, force?: boolean): boolean;
    createInterfaces(): Promise<void>;
    createBuiltinInterfaces(): void;
    injectDependencies(): void;
    run(): Promise<void>;
}
export {};
