import { File } from '../file/File';
import { caseType } from '../utils/casing';
export declare class ExtraType extends File {
    protected typeString: string;
    constructor(typeString: string, baseName: string, relativeDirectoryPath: string, fileCaseType?: caseType);
    getDependencies(): any[];
    getStrapiName(): string;
    getFullName(): string;
    protected updateStrapiName(): void;
    toString(): string;
}
