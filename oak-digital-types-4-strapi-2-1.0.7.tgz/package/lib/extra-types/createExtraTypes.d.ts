import { ExtraType } from './ExtraType';
export declare const createExtraTypes: () => ExtraType[];
