import { File } from '../file/File';
import { InterfaceWriter } from './types/writer';
import prettier from 'prettier';
type BasicWriterOptions = {
    /**
     * Warning: this will delete all files in the output directory!
     * @default false
     * @type {boolean}
     */
    deleteOld?: boolean;
    prettierOptions?: prettier.Options;
    indexFile?: boolean;
};
export declare class BasicWriter implements InterfaceWriter {
    protected OutRootPath: string;
    private DeleteOld;
    private PrettierOptions;
    private IndexFile;
    constructor(outRootPath: string, { deleteOld, indexFile, prettierOptions, }: BasicWriterOptions);
    write(data: File[]): Promise<void>;
    writeIndexFile(data: File[]): Promise<void>;
    makeFolders(data: File[]): Promise<void>;
}
export {};
