import { z } from 'zod';
export declare const baseAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
}>;
export declare const textAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEnum<["text", "string"]>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "string" | "text";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "string" | "text";
}>;
export type TextAttribute = z.infer<typeof textAttribute>;
export declare const emailAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"email">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "email";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "email";
}>;
export type EmailAttribute = z.infer<typeof emailAttribute>;
export declare const uidAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"uid">;
    targetField: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "uid";
    targetField?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "uid";
    targetField?: string;
}>;
export type UidAttribute = z.infer<typeof uidAttribute>;
export declare const richTextAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"richtext">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "richtext";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "richtext";
}>;
export type RichTextAttribute = z.infer<typeof richTextAttribute>;
export declare const blocksAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"blocks">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "blocks";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "blocks";
}>;
export declare const jsonAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"json">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "json";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "json";
}>;
export type JsonAttribute = z.infer<typeof jsonAttribute>;
export declare const passwordAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"password">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "password";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "password";
}>;
export type PasswordAttribute = z.infer<typeof passwordAttribute>;
export declare const integerAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"integer">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "integer";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "integer";
}>;
export declare const floatAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"float">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "float";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "float";
}>;
export declare const bigIntAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"biginteger">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "biginteger";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "biginteger";
}>;
export declare const decimalAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"decimal">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "decimal";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "decimal";
}>;
export declare const numberAttribute: z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"integer">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "integer";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "integer";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"float">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "float";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "float";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"biginteger">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "biginteger";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "biginteger";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"decimal">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "decimal";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "decimal";
}>]>;
export type NumberAttribute = z.infer<typeof numberAttribute>;
export declare const enumAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"enumeration">;
    enum: z.ZodArray<z.ZodString, "many">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "enumeration";
    enum?: string[];
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "enumeration";
    enum?: string[];
}>;
export type EnumAttribute = z.infer<typeof enumAttribute>;
export declare const dateOnlyAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"date">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "date";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "date";
}>;
export declare const dateTimeAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"datetime">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "datetime";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "datetime";
}>;
export declare const timeAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"time">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "time";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "time";
}>;
export declare const dateAttribute: z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"date">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "date";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "date";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"datetime">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "datetime";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "datetime";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"time">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "time";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "time";
}>]>;
export type DateAttribute = z.infer<typeof dateAttribute>;
export declare const mediaAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"media">;
    multiple: z.ZodOptional<z.ZodBoolean>;
    allowedTypes: z.ZodDefault<z.ZodOptional<z.ZodArray<z.ZodEnum<["images", "videos", "audios", "files"]>, "many">>>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "media";
    multiple?: boolean;
    allowedTypes?: ("images" | "videos" | "audios" | "files")[];
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "media";
    multiple?: boolean;
    allowedTypes?: ("images" | "videos" | "audios" | "files")[];
}>;
export type MediaAttribute = z.infer<typeof mediaAttribute>;
export declare const booleanAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"boolean">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "boolean";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "boolean";
}>;
export type BooleanAttribute = z.infer<typeof booleanAttribute>;
export declare const baseRelationAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    target?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    target?: string;
}>;
export declare const hasOneAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToOne">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
}>;
export declare const oneToOneAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToOne">;
    inversedBy: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
    inversedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
    inversedBy?: string;
}>;
export declare const belongsToManyAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    mappedBy: z.ZodString;
    relation: z.ZodLiteral<"oneToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
    mappedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
    mappedBy?: string;
}>;
export declare const manyToOneAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"manyToOne">;
    inversedBy: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToOne";
    target?: string;
    inversedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToOne";
    target?: string;
    inversedBy?: string;
}>;
export declare const manyToManyAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"manyToMany">;
    inversedBy: z.ZodOptional<z.ZodString>;
    mappedBy: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToMany";
    target?: string;
    inversedBy?: string;
    mappedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToMany";
    target?: string;
    inversedBy?: string;
    mappedBy?: string;
}>;
export declare const hasManyAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
}>;
export declare const morphToManyAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    relation: z.ZodLiteral<"morphToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToMany";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToMany";
}>;
export declare const morphOneAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    relation: z.ZodLiteral<"morphToOne">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToOne";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToOne";
}>;
export declare const relationAttribute: z.ZodUnion<[z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToOne">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToOne">;
    inversedBy: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
    inversedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
    inversedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    mappedBy: z.ZodString;
    relation: z.ZodLiteral<"oneToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
    mappedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
    mappedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"manyToOne">;
    inversedBy: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToOne";
    target?: string;
    inversedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToOne";
    target?: string;
    inversedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"manyToMany">;
    inversedBy: z.ZodOptional<z.ZodString>;
    mappedBy: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToMany";
    target?: string;
    inversedBy?: string;
    mappedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToMany";
    target?: string;
    inversedBy?: string;
    mappedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    relation: z.ZodLiteral<"morphToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToMany";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToMany";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    relation: z.ZodLiteral<"morphToOne">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToOne";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToOne";
}>]>;
export type RelationAttribute = z.infer<typeof relationAttribute>;
export declare const componentAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"component">;
    repeatable: z.ZodOptional<z.ZodBoolean>;
    component: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "component";
    component?: string;
    repeatable?: boolean;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "component";
    component?: string;
    repeatable?: boolean;
}>;
export type ComponentAttribute = z.infer<typeof componentAttribute>;
export declare const dynamiczoneAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"dynamiczone">;
    components: z.ZodArray<z.ZodString, "many">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "dynamiczone";
    components?: string[];
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "dynamiczone";
    components?: string[];
}>;
export type DynamiczoneAttribute = z.infer<typeof dynamiczoneAttribute>;
export declare const knownAttribute: z.ZodUnion<[z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEnum<["text", "string"]>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "string" | "text";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "string" | "text";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"email">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "email";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "email";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"uid">;
    targetField: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "uid";
    targetField?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "uid";
    targetField?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"richtext">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "richtext";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "richtext";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"blocks">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "blocks";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "blocks";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"json">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "json";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "json";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"password">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "password";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "password";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"integer">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "integer";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "integer";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"float">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "float";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "float";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"biginteger">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "biginteger";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "biginteger";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"decimal">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "decimal";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "decimal";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"enumeration">;
    enum: z.ZodArray<z.ZodString, "many">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "enumeration";
    enum?: string[];
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "enumeration";
    enum?: string[];
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"date">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "date";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "date";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"datetime">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "datetime";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "datetime";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"time">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "time";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "time";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"media">;
    multiple: z.ZodOptional<z.ZodBoolean>;
    allowedTypes: z.ZodDefault<z.ZodOptional<z.ZodArray<z.ZodEnum<["images", "videos", "audios", "files"]>, "many">>>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "media";
    multiple?: boolean;
    allowedTypes?: ("images" | "videos" | "audios" | "files")[];
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "media";
    multiple?: boolean;
    allowedTypes?: ("images" | "videos" | "audios" | "files")[];
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"boolean">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "boolean";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "boolean";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToOne">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToOne">;
    inversedBy: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
    inversedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
    inversedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    mappedBy: z.ZodString;
    relation: z.ZodLiteral<"oneToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
    mappedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
    mappedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"manyToOne">;
    inversedBy: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToOne";
    target?: string;
    inversedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToOne";
    target?: string;
    inversedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"manyToMany">;
    inversedBy: z.ZodOptional<z.ZodString>;
    mappedBy: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToMany";
    target?: string;
    inversedBy?: string;
    mappedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToMany";
    target?: string;
    inversedBy?: string;
    mappedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    relation: z.ZodLiteral<"morphToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToMany";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToMany";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    relation: z.ZodLiteral<"morphToOne">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToOne";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToOne";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"component">;
    repeatable: z.ZodOptional<z.ZodBoolean>;
    component: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "component";
    component?: string;
    repeatable?: boolean;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "component";
    component?: string;
    repeatable?: boolean;
}>]>;
export type KnownAttribute = z.infer<typeof knownAttribute>;
export declare const anyAttribute: z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
}, "passthrough", z.ZodTypeAny, z.objectOutputType<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
}, z.ZodTypeAny, "passthrough">, z.objectInputType<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
}, z.ZodTypeAny, "passthrough">>;
export type AnyAttribute = z.infer<typeof anyAttribute>;
export declare const attribute: z.ZodUnion<[z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEnum<["text", "string"]>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "string" | "text";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "string" | "text";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"email">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "email";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "email";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"uid">;
    targetField: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "uid";
    targetField?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "uid";
    targetField?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"richtext">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "richtext";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "richtext";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"blocks">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "blocks";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "blocks";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"json">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "json";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "json";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"password">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "password";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "password";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"integer">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "integer";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "integer";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"float">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "float";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "float";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"biginteger">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "biginteger";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "biginteger";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"decimal">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "decimal";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "decimal";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"enumeration">;
    enum: z.ZodArray<z.ZodString, "many">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "enumeration";
    enum?: string[];
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "enumeration";
    enum?: string[];
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"date">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "date";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "date";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"datetime">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "datetime";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "datetime";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"time">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "time";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "time";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"media">;
    multiple: z.ZodOptional<z.ZodBoolean>;
    allowedTypes: z.ZodDefault<z.ZodOptional<z.ZodArray<z.ZodEnum<["images", "videos", "audios", "files"]>, "many">>>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "media";
    multiple?: boolean;
    allowedTypes?: ("images" | "videos" | "audios" | "files")[];
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "media";
    multiple?: boolean;
    allowedTypes?: ("images" | "videos" | "audios" | "files")[];
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"boolean">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "boolean";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "boolean";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToOne">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToOne">;
    inversedBy: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
    inversedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
    inversedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    mappedBy: z.ZodString;
    relation: z.ZodLiteral<"oneToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
    mappedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
    mappedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"manyToOne">;
    inversedBy: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToOne";
    target?: string;
    inversedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToOne";
    target?: string;
    inversedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"manyToMany">;
    inversedBy: z.ZodOptional<z.ZodString>;
    mappedBy: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToMany";
    target?: string;
    inversedBy?: string;
    mappedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToMany";
    target?: string;
    inversedBy?: string;
    mappedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    relation: z.ZodLiteral<"morphToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToMany";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToMany";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    relation: z.ZodLiteral<"morphToOne">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToOne";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToOne";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"component">;
    repeatable: z.ZodOptional<z.ZodBoolean>;
    component: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "component";
    component?: string;
    repeatable?: boolean;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "component";
    component?: string;
    repeatable?: boolean;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
}, "passthrough", z.ZodTypeAny, z.objectOutputType<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
}, z.ZodTypeAny, "passthrough">, z.objectInputType<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
}, z.ZodTypeAny, "passthrough">>]>;
export type Attribute = z.infer<typeof attribute>;
export declare const isKnownAttribute: <T extends Attribute>(attributeObject: T) => attributeObject is T & KnownAttribute;
export declare const contentTypeAttribute: z.ZodUnion<[z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"dynamiczone">;
    components: z.ZodArray<z.ZodString, "many">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "dynamiczone";
    components?: string[];
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "dynamiczone";
    components?: string[];
}>, z.ZodUnion<[z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEnum<["text", "string"]>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "string" | "text";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "string" | "text";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"email">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "email";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "email";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"uid">;
    targetField: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "uid";
    targetField?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "uid";
    targetField?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"richtext">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "richtext";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "richtext";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"blocks">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "blocks";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "blocks";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"json">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "json";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "json";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"password">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "password";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "password";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"integer">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "integer";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "integer";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"float">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "float";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "float";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"biginteger">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "biginteger";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "biginteger";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"decimal">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "decimal";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "decimal";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"enumeration">;
    enum: z.ZodArray<z.ZodString, "many">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "enumeration";
    enum?: string[];
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "enumeration";
    enum?: string[];
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"date">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "date";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "date";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"datetime">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "datetime";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "datetime";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"time">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "time";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "time";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"media">;
    multiple: z.ZodOptional<z.ZodBoolean>;
    allowedTypes: z.ZodDefault<z.ZodOptional<z.ZodArray<z.ZodEnum<["images", "videos", "audios", "files"]>, "many">>>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "media";
    multiple?: boolean;
    allowedTypes?: ("images" | "videos" | "audios" | "files")[];
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "media";
    multiple?: boolean;
    allowedTypes?: ("images" | "videos" | "audios" | "files")[];
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"boolean">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "boolean";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "boolean";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToOne">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToOne">;
    inversedBy: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
    inversedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToOne";
    target?: string;
    inversedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    mappedBy: z.ZodString;
    relation: z.ZodLiteral<"oneToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
    mappedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
    mappedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"manyToOne">;
    inversedBy: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToOne";
    target?: string;
    inversedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToOne";
    target?: string;
    inversedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"manyToMany">;
    inversedBy: z.ZodOptional<z.ZodString>;
    mappedBy: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToMany";
    target?: string;
    inversedBy?: string;
    mappedBy?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "manyToMany";
    target?: string;
    inversedBy?: string;
    mappedBy?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    target: z.ZodString;
} & {
    relation: z.ZodLiteral<"oneToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "oneToMany";
    target?: string;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    relation: z.ZodLiteral<"morphToMany">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToMany";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToMany";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"relation">;
    relation: z.ZodLiteral<"morphToOne">;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToOne";
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "relation";
    relation?: "morphToOne";
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodLiteral<"component">;
    repeatable: z.ZodOptional<z.ZodBoolean>;
    component: z.ZodString;
}, "strip", z.ZodTypeAny, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "component";
    component?: string;
    repeatable?: boolean;
}, {
    __t4s_required?: boolean;
    pluginOptions?: any;
    required?: boolean;
    type?: "component";
    component?: string;
    repeatable?: boolean;
}>, z.ZodObject<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
}, "passthrough", z.ZodTypeAny, z.objectOutputType<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
}, z.ZodTypeAny, "passthrough">, z.objectInputType<{
    pluginOptions: z.ZodOptional<z.ZodAny>;
    required: z.ZodOptional<z.ZodBoolean>;
    __t4s_required: z.ZodOptional<z.ZodBoolean>;
} & {
    type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
}, z.ZodTypeAny, "passthrough">>]>]>;
export type ContentTypeAttribute = z.infer<typeof contentTypeAttribute>;
