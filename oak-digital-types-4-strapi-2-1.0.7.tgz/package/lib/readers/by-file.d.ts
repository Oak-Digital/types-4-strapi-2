import { ContentTypeReader } from './types/content-type-reader';
export declare class ByFileContentTypeReader implements ContentTypeReader {
    private readonly strapiSrcRoot;
    constructor(strapiRoot: string);
    readComponents(): Promise<Record<`${string}.${string}`, {
        options?: {};
        uid?: string;
        collectionName?: string;
        attributes?: Record<string, {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "string" | "text";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "email";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "uid";
            targetField?: string;
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "richtext";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "blocks";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "json";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "password";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "integer";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "float";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "biginteger";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "decimal";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "enumeration";
            enum?: string[];
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "date";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "datetime";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "time";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "media";
            multiple?: boolean;
            allowedTypes?: ("images" | "videos" | "audios" | "files")[];
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "boolean";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "oneToOne";
            target?: string;
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "oneToOne";
            target?: string;
            inversedBy?: string;
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "oneToMany";
            target?: string;
            mappedBy?: string;
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "manyToOne";
            target?: string;
            inversedBy?: string;
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "manyToMany";
            target?: string;
            inversedBy?: string;
            mappedBy?: string;
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "oneToMany";
            target?: string;
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "morphToMany";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "morphToOne";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "component";
            component?: string;
            repeatable?: boolean;
        } | import("zod").objectOutputType<{
            pluginOptions: import("zod").ZodOptional<import("zod").ZodAny>;
            required: import("zod").ZodOptional<import("zod").ZodBoolean>;
            __t4s_required: import("zod").ZodOptional<import("zod").ZodBoolean>;
        } & {
            type: import("zod").ZodEffects<import("zod").ZodType<"any", import("zod").ZodTypeDef, "any">, "any", "any">;
        }, import("zod").ZodTypeAny, "passthrough">>;
    }>>;
    readContentTypes(): Promise<Record<`api::${string}` | `plugin::${string}` | `admin::${string}` | `builtins::${string}`, {
        name: string;
        contentType: import("./types/content-type").StrapiContentType;
    } & ({
        namespace: "api" | "plugin";
        collection: string;
    } | {
        namespace: "admin";
        collection?: null | undefined;
    })>>;
    private readComponentSchema;
    private readContentTypeSchema;
    private getApiFolders;
    private getComponentCategoryFolders;
}
