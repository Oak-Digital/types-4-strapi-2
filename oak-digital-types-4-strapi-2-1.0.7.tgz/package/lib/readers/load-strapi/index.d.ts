import { z } from 'zod';
import { StrapiContentType } from '../types/content-type';
import { ContentTypeReader } from '../types/content-type-reader';
export declare class LoadStrapiReader implements ContentTypeReader {
    private strapiRoot;
    private loadStrapiPromise;
    constructor(strapiRoot: string);
    readContentTypes(): Promise<Record<`api::${string}` | `plugin::${string}` | `admin::${string}` | `builtins::${string}`, {
        name: string;
        contentType: StrapiContentType;
    } & ({
        namespace: "api" | "plugin";
        collection: string;
    } | {
        namespace: "admin";
        collection?: null | undefined;
    })>>;
    readComponents(): Promise<Record<string, {
        options?: {};
        uid?: string;
        collectionName?: string;
        attributes?: Record<string, {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "string" | "text";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "email";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "uid";
            targetField?: string;
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "richtext";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "blocks";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "json";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "password";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "integer";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "float";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "biginteger";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "decimal";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "enumeration";
            enum?: string[];
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "date";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "datetime";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "time";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "media";
            multiple?: boolean;
            allowedTypes?: ("images" | "videos" | "audios" | "files")[];
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "boolean";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "oneToOne";
            target?: string;
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "oneToOne";
            target?: string;
            inversedBy?: string;
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "oneToMany";
            target?: string;
            mappedBy?: string;
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "manyToOne";
            target?: string;
            inversedBy?: string;
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "manyToMany";
            target?: string;
            inversedBy?: string;
            mappedBy?: string;
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "oneToMany";
            target?: string;
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "morphToMany";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "relation";
            relation?: "morphToOne";
        } | {
            __t4s_required?: boolean;
            pluginOptions?: any;
            required?: boolean;
            type?: "component";
            component?: string;
            repeatable?: boolean;
        } | z.objectOutputType<{
            pluginOptions: z.ZodOptional<z.ZodAny>;
            required: z.ZodOptional<z.ZodBoolean>;
            __t4s_required: z.ZodOptional<z.ZodBoolean>;
        } & {
            type: z.ZodEffects<z.ZodType<"any", z.ZodTypeDef, "any">, "any", "any">;
        }, z.ZodTypeAny, "passthrough">>;
    }>>;
    private loadStrapi;
}
