export declare function readSchema(schemaPath: string): Promise<any>;
export declare function getApiFolders(strapiSrcRoot: string): Promise<string[]>;
export declare function getComponentCategoryFolders(strapiSrcRoot: string): Promise<string[]>;
export declare function getComponentSchemas(strapiSrcRoot: string): Promise<{
    category: string;
    schemas: {
        name: string;
        schema: any;
    }[];
}[]>;
export declare function getApiSchemas(strapiSrcRoot: string): Promise<{
    name: string;
    schema: any;
}[]>;
