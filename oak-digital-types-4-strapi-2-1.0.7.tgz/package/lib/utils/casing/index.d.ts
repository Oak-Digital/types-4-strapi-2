export declare const caseTypesArray: readonly ["camel", "capital", "dot", "snake", "pascal", "constant", "kebab"];
export type caseType = typeof caseTypesArray[number];
export declare function checkCaseType(caseName: caseType): caseName is caseType;
export declare function changeCase(text: string, caseName: caseType): string;
