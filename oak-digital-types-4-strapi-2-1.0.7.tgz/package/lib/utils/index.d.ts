export declare function readDirFiltered(dir: string): Promise<string[]>;
export declare function prefixDotSlash(path: any): any;
