import { File } from '../../file/File';
export declare class UrlAliasGet extends File {
    constructor();
    getStrapiName(): string;
    getFullName(): string;
    getDependencies(): any[];
    toString(): string;
}
