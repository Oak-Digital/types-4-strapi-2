import { SupportedPluginNamesType } from './types';
import { PluginManager } from './PluginManager';
export declare const registerBuiltinPlugins: (pluginManager: PluginManager, pluginNames: Set<SupportedPluginNamesType>) => void;
