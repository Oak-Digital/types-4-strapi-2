import { PluginRegister } from '../types';
declare const register: PluginRegister;
export default register;
