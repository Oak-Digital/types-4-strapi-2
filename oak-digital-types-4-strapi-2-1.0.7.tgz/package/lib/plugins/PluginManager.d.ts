import { Events } from '../events';
import InterfaceManager from '../program/InterfaceManager';
import { ContentTypeReader } from '../readers/types/content-type-reader';
type Schemas = {
    apiSchemas: Awaited<ReturnType<ContentTypeReader['readContentTypes']>>;
    componentSchemas: Awaited<ReturnType<ContentTypeReader['readComponents']>>;
};
export type HookTypes = {
    [Events.BeforeReadSchema]: (state: InterfaceManager, schema: Schemas) => void;
    [Events.AfterReadSchema]: (state: InterfaceManager, schema: Schemas) => void;
    [Events.BeforeReadSchemas]: (state: InterfaceManager) => void;
    [Events.AfterReadSchemas]: (state: InterfaceManager) => void;
    [Events.ModifySchemas]: (state: InterfaceManager) => void;
    [Events.BeforeInjectDependencies]: (state: InterfaceManager) => void;
    [Events.AfterInjectDependencies]: (state: InterfaceManager) => void;
};
export type HooksType = {
    [HookType in keyof HookTypes]: {
        fn: HookTypes[HookType];
        priority: number;
    }[];
};
export declare class PluginManager {
    hooks: HooksType;
    registerPlugin(hooks: Partial<HooksType>): void;
    registerHook<Hook extends keyof HookTypes>(hook: Hook, fn: HookTypes[Hook], priority: number): void;
    sortHooks(): void;
    invoke<Hook extends keyof HookTypes>(hook: Hook, ...args: Parameters<HookTypes[Hook]>): void;
}
export {};
