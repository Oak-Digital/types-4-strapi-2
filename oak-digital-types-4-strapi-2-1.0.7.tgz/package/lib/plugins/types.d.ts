import { HooksType } from './PluginManager';
export declare const supportedPluginNames: readonly ["url-alias", "i18n"];
export type SupportedPluginNamesType = typeof supportedPluginNames[number];
export type PluginRegister = () => Partial<HooksType>;
