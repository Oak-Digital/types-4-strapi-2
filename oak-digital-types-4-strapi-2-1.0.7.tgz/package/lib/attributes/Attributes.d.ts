import { RelationNames } from '../file/File';
import { AttributeWithNested } from '../interface/builtinInterfaces';
export default class Attributes {
    Attrs: Record<string, AttributeWithNested>;
    private RelationNames;
    constructor(attr: Record<string, Record<string, any>>, relationNames: RelationNames);
    isAttributePopulatable(attr: AttributeWithNested): boolean;
    hasPopulatableAttributes(): boolean;
    getPopulatableAttributes(): Set<string>;
    getDependencies(): string[];
    attributeToString(attrName: string, attr: AttributeWithNested): string;
    toFieldsString(): string;
    toString(): string;
}
